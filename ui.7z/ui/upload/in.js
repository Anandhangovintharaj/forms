var cars = 2
do {
    cars /= 2;

}
while (cars < 1)
console.log("num" + cars)